#!/bin/sh -e
# ESET PROTECT
# Copyright (c) 1992-2023 ESET, spol. s r.o. All Rights Reserved

cleanup_file="$(mktemp -q)"
finalize()
{
  set +e
  if test -f "$cleanup_file"
  then
    while read f
    do
      rm -f "$f"
    done < "$cleanup_file"
    rm -f "$cleanup_file"
  fi
}

trap 'finalize' HUP INT QUIT TERM EXIT

eraa_server_hostname="ESET01.cl.local"
eraa_server_port="2222"
eraa_server_company_name=""
eraa_peer_cert_b64="MIIMxQIBAzCCDI8GCSqGSIb3DQEHAaCCDIAEggx8MIIMeDCCBO8GCSqGSIb3DQEHBqCCBOAwggTcAgEAMIIE1QYJKoZIhvcNAQcBMBwGCiqGSIb3DQEMAQYwDgQIvkr2WstGbG4CAggAgIIEqNak/BagOZhXr6EzGvPuQAOniE0zoBGSuJkpJkeXIg2PR/+zgcVCr944IahQS4A2z9rjmrPRdShC8MZNlRErrJUqqkUQtXR7ALTTXzkMgKEjnEKmCxMizNBk3b0mQkwaZoNXqHAwCIsiH1gPkTC7r2rezh70FR2WqWwOlUpRflDxVqA0XYCLVJkLrddls+5Zaov7ggbMmj/G+c4rNnN7Hr3dQbP0iJqyepuYdbRfUg0ybeei/Wh6Kgeq053nTZ//JWyQ3QQMIWHYERb/MySrG8Ws5k9R1kzJa/6DIeTPJFE1jOpFcpuRn5x29xNLzDBRzppVDcNBDdlQnUnUTIPPAnt2x431KFM2dGklt8HFgqqGWhCubmevY7sVVoHgpJZEaUQobnBGzagLNN3Sx/5LGOk30Yo8O2OXhRhkc4kDHjjROIuzdptBRUU8zuJIEw+xqRozTp785LeDbUImiFfdlSFJgssvgapXE5lYl14W/Uldm0hv7RxaYgW73z/iSFGO3/1jZTjVHnfxmTGWTRA28NBzxIkwO6hWFcKWU6KNqdZeOsk3heL5m8+O8JDX6NPyiSzVCmZ49A9v5XMvmgaOrENAP3z2dEWl6R+FB4vp9KdpJvzBTzEWTDVxqYzpXbiZLKoGeotUls7BEWB94lmA3Ln9IcHu2VDq6GHPELRal5xf40iLleSlIa9tgdLmyw5WBFJVhpI3QZonD5MlB6vFTLIuLz/ETctDRwOuFO1BSWQGNtl9G9I7Of0R4syN+9kSl7s6jQqPxbPk7HzNVzd920PX9Glz/FncLHyKZFONRfmjp572Uov32c95UXSZpa2Gr51tT7XJ6JaR6dZn/c+/KIPrN2HmRCkiMDfdH2pSj7ZSsE7nvWt/0DQQCasrYRRC1u4cevOsr42fwyVQQafF/zkXaZ004L3EGPVFYneJoE0H7y+coSOhVdVjArl2OrQ9vrgeGsTsbaSHYhJ+0qC0mpv3QwPA/PfZkrwGqdapBAt3x/ODma0lNjGOamkxNmYHT6yf6LKtPZyDVWaQG5/OXSS0frAWxcdGG2dHUoL1Fcn5nnxnXFSbUZoxjjmUU2AC8vH4Uo3I1jmSflcSBVUpYJwhVnS0mtP99hFMk4qicigTrb12SBRfVYQ9QITF8lONVSO88vLizNBDGdVhw2CR9q+kBX+KfAmkVbtBQwpgSuZuOVxdC4t9WJpWVsGlv5JdhRGJgiqUMqGWCapuCNViD4+Yo3nuHciDpYUf70uJvw4A0ProSYpcLIZTBV4EvlniADRNLFhDw4NXB0TOx/IErPS2khoZUZg5pqSzzsb4Zox1FOqrbHxUtbBaFMwfWikRZuj8UcPMMG9f4vw6D508Nf8i+/298pnvmFUy0PU6jN+K5PLQOYsQ/Rj3qrdweHj0wBZto1BlhkkhGBxAbUW+9su3FBjiL8I///lYTMQCpGvEpkpxkFipw7VRpNn3UHSAsUkiWwNkQ2/I0fricgcHf1pMq/l00JztWZDIHkDEe9Kls49ZihsdUp3IWCuWKwOTzSW/YsC3oyoGFWm6x0T66k1H7rKEA8/nNl9yH7kUiRoBsaYYaVctnu8wggeBBgkqhkiG9w0BBwGgggdyBIIHbjCCB2owggdmBgsqhkiG9w0BDAoBAqCCBy4wggcqMBwGCiqGSIb3DQEMAQMwDgQIveqfVAnkp38CAggABIIHCJXLFwuqxsYUISKYuo54c97T6PXCfpIuObMjP5RcWS0ZxIRFqIqS77G68gW+FHnLnxwQZDxYWYe3KFz1V9KWv1Q8OMc60erbEkJa7NhHJuy7r2CH3T9WdWydn70s1tNgf/sKMB/oKR9JQtDyOzR++DJcfiujSuDUfsJkPAB70ZCmjAf8Pwqp1KoV6HAIdG2V/X/Yy0ifIx/QUDgXq+O5B7Dhr00rwv4xNSebPYPykrIFG6xGcSy+6awN9Z8SdzmBhWgMWMe/mG1E7v8uopsGembwh6kNFfmjZaUo609e7Maom9B16QhTfA+3HyAavkInbdfgWso4trywqNjNhAXdkOu9lR55vxUwltJIwHx/ZTYZyu2K0QP0WH5Epd1Fqd3hNAbmbmjrK1SF4pic5kWdnNstc2Z61UJL5KFv6Oebe2toMINBkgu7QZ4LSQ/Xp1c5kNDdd2tjNzTkhu/fPQ6DxDkd56pkeaYyw4/P7lh4PqHSYetX9NryMWs/4m/aSqkC1RvICb40YQsPuO1E3nlRGygw/qQVKi1o0AjnTe9wCtBBLs31/Qjbm8O8P6nj01nnimb5oyank5Ifvi/2ypzpgoKBM+t7FOhKRU0x7I1ltqfAAlpxbN2WbfiFoBtoKdUbSQUy2d+uNtTIDOfP/C3ynzE3OOQdC26YgvSS+vyjIqhVIwXcoDFnxTxBjBK35Cs4Rk3dbnM3392xt/jxw/o8enaDWo0w8NjZ//FSI9467WtE+nitihkGUUhvhZO+odVi+RB+wpD/PDRg6PXW3JSC28Tganhb/vWN6zcymj37r30RcOAxpk0oYyH5uOAuZ/lTG7bxAi5Om9FCSbASX9Abo7QIgUON9KzMcs245SzDABNYiLwAATR6OXncCHyPfoOSj6tuzby3Ds22PPsjyduhu2dj0D1Pb1e9URjkUiKx5E+SPsw1PeJtD7f2/uWkx46/y841FHiuB7nigG5cYPi5uch5ZoR6nkQL0GcsVxzvTU+MUaeeC05Q1OtnD7y2AmohxtUA33OLG98klXxCW3ipVcqW/hMGWT4AxFVcwAqcDMytwKWpVW3EFTzXoU2MFqoF5/oLtp9PxADnUqqg504T9jPDs5Je73LxxFe/kFtciugYB3EXOQ5r9lYfn+JH3lhtWMi1POIKIlMjhL0xJXB3HExrjuYZNnF7YlpFYOH5xT6kygigHL7GxJqVUEs1lQTOEt53wkFoCI9Sk3pZlMR54zCmPoRWfokFNZaH1GnpmlWT+GzduwnX4QwSOmoQBgvyrH2l9X3ncemtXjBtphgbQVewxDXnKLe5zFDyVs/x/ILo5VWZTipIZl4Pq+s4L3CtQqKhhkCXRfcIJafMw8u6EMJuudgFHcpblYPp762lrSWw+Xl78wRDTkqnsbl2Uy5BSjLZMPgj0YzG/oKjqyF3YeYpdHJAckHHWNJUTmSYwjurEfkwiX1Q2hE5uekj5Nc/yDHzLdDyw6UZ0kEA5GAZvVeEqokku60W97l/vNlWuUXfjyF28wJ/Mat5yWaX71/nEhC6Gt5RcWLgQAmt1ggNP1+zjFG0aKe4paKjSyjtvhFV9A50cT+FdbLCDbwB5DcXov+NuGy+NDyUrn8QV2lhawYQqFcUUW71nW00qVp3U3gEFchxN6QNlTNArqymrV8u3NpV9vS2nTmZWpKQb/IFdWnEWaq3z0nP9l98JbjZFUMe/F8VV9hi2yVW5Ba3VY/K0QLsxXOtBUDijqy+MKNpoe0Z74naBTxSscLg7kqMAsyWdv4Am7Tz0mQUTp6WyW6FprKaO2pnK8FBSuqQwjSEJXZJHQG/V65iC459xzdyxdg6ykcrGh9c1W4tgHZxSK2famvuRw0YNKR/mV8+lFU8GnhlT+aU6B+ybGORz3hMWbCV8LnKZHx1ycq0vP+so1EQi8xF8EUqjDPDOqR5ZS+DMJm0/CaiyIhYDGZIQ+kT3NEhlUwvVPkcEK0kkolmy5jL/NBLErz+mqsU0iv7QgSzAB4+kPxWre+fnBofv6d8yDLipCfdOJ/Zohd3saa2nOgGXN/nyQaBflPbZCRhzH/QERl7280pxAks245O/WeeLaD8J/+5K/y8bqhqM/wxYZAfBMOQOzVGSSF4jCr6Rnn7xdioFarb9jxI0Uit44HadTVc3D13doV796u1HiUTScu4+zG6Ls+asZCLV/rsTgAFdcMF7CxbZQXPegtRVqsX67pjojKPkiL5/AanFlrX9FHaFkQ8b/Mek6AUrrTzIyRBjGbNVe9od8EPIEupBp+SdeiL7ZLmG2XA3gPoeV3NZe5A9vL1Lz75frcXsXO8fpyvrEwZPNOzl5CBXMA/E3n0Bd8axel5xK6P7tReXwgOokZoz9Is3twS1H48dbEdmdvLO5T+ECLIot9dlDElMCMGCSqGSIb3DQEJFTEWBBQjVN/RCFYJlRQLzjnjmZkqkWlReDAtMCEwCQYFKw4DAhoFAAQUV3SH5ODRvwRcmukJwMktVi+5h1gECPZamQ8oyts7"
eraa_peer_cert_pwd=""
eraa_ca_cert_b64="MIIEWzCCAsOgAwIBAgISAdIS9OoJSUEeohXK4rkezJUBMA0GCSqGSIb3DQEBCwUAMDYxJzAlBgNVBAMMHlNlcnZlciBDZXJ0aWZpY2F0aW9uIEF1dGhvcml0eTELMAkGA1UEBhMCVVMwHhcNMjMwMTAzMjMwMDAwWhcNMzMwMTA0MjMwMDAwWjA2MScwJQYDVQQDDB5TZXJ2ZXIgQ2VydGlmaWNhdGlvbiBBdXRob3JpdHkxCzAJBgNVBAYTAlVTMIIBojANBgkqhkiG9w0BAQEFAAOCAY8AMIIBigKCAYEA2Nm8jZFle39pCS1Xfee8YDWkaQ4kt1KYjpLE4SlKM+tcpjPBylBRLyoiIdyVBH09mCoOhpKllLhP8iqtopJ7WMsgRoThNFJwgvmxUMiPV8gVCM0GeszSyLacavTjpz96QHkZs+ysECndmHmbZ6dZ7lNrD3xCjB8Q00mu7e2fqMl1DTUwfcb16lfQQ7c0soU5Yz7pt1NErO2hHTN9gxOa9or6AzlULvSaoT1FiHdDaLFpbNgPGTj67sidMnG6v/Ft3p8IDvNzCTp4QFjhkCojvAf9OwyN7aOvd15f34+Fe7X8DIrS8GfhGDcUepU/7PoZUZr8I0+80yO8zop9cJM78NxbJ2DxKy9Kk5+qxyuLs6OecFVvYtOipbRDZO8Rx8AWxoHbMZkMRzG7MJZMpjj/uq5XwFH2fM+P5sRmwfVS3fFa/SBdkgKDpNu0+rmCo7T+WX0//pnj1QknTxU+3U3l1dvE+DcpRfoo58C7fLKQaX9S4Rq7rojRshNUhi7kKaFbAgMBAAGjYzBhMA4GA1UdDwEB/wQEAwIBBjAPBgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBSWD5cJdoXgLhveIHaz8wYUpwSjszAfBgNVHSMEGDAWgBSWD5cJdoXgLhveIHaz8wYUpwSjszANBgkqhkiG9w0BAQsFAAOCAYEAk39FhLoAYonD/qT0ktB0VlZr5B9XeqIMBhP+ap4HWsDQ4VHEVGWLTSEtTpY/f3aIIGTCSCNOP7sG1Vz3393V8i5dhHPVAvYGr6z3yR74Jza8m6W/CKnb0AA57N1Z9NgpFZKBqN7pChkJ5MavQ9FdTTtwetfeo7lq2eEsh0Ae+yBZr2BvOJzsBtwN68sFvUw5cAo6WfoLlpjg9zeR5DnAsMwzWiXpNby2z+Da7wZUNdL/vrITMowAzsNdMKoMv9HrUbiaet2GDUgymCF9Ytyv+wgr3VzNUkCwn5++PmwhRt1MVgxZSsNb7a1SaYMTNEt7G9OBTa+1z3Ve7OGroAjROWsBvquN0Ihn+tS/G/69agnTbpv4cMJbwa4CTjZW2zFLU7CBgyLjQ8/mn8fKnyC2xuQGz+VDmqCf5+IAlBlUlbaAkPViL/uiVQiON4otDVkRPIpSVxnKHYe6/McsPf3OhjE4xQsPX6n4g2bZPbKRkfv0akeki48dj2RTmjw8tzTB"
eraa_product_uuid=""
eraa_initial_sg_token=""
eraa_policy_data=""

arch=$(uname -m)
eraa_installer_url="http://repository.eset.com/v1/com/eset/apps/business/era/agent/v10/10.1.2267.0/agent_linux_i386.sh"
eraa_installer_checksum="fe9429421856179e0d863fcb038f9384551728a77537de8ca6dac04e4a691742"

if $(echo "$arch" | grep -E "^(x86_64|amd64)$" 2>&1 > /dev/null)
then
    eraa_installer_url="http://repository.eset.com/v1/com/eset/apps/business/era/agent/v10/10.1.2267.0/agent_linux_x86_64.sh"
    eraa_installer_checksum="69ef30ab953f10f12a95613d1352e0638742c9fb36938d313948bd431edc3134"
fi

echo "ESET Management Agent live installer script. Copyright © 1992-2023 ESET, spol. s r.o. - All rights reserved."

if test ! -z $eraa_server_company_name
then
  echo " * CompanyName: $eraa_server_company_name"
fi
echo " * Hostname: $eraa_server_hostname"
echo " * Port: $eraa_server_port"
echo " * Installer: $eraa_installer_url"
echo

if test -z $eraa_installer_url
then
  echo "No installer available for '$arch' arhitecture."
  exit 1
fi

local_cert_path="$(mktemp -q -u)"
echo $eraa_peer_cert_b64 | base64 -d > "$local_cert_path" && echo "$local_cert_path" >> "$cleanup_file"

if test -n "$eraa_ca_cert_b64"
then
  local_ca_path="$(mktemp -q -u)"
  echo $eraa_ca_cert_b64 | base64 -d > "$local_ca_path" && echo "$local_ca_path" >> "$cleanup_file"
fi


eraa_http_proxy_value="http://ESET01:3128"

local_installer="$(dirname $0)"/"$(basename $eraa_installer_url)"

if $(echo "$eraa_installer_checksum  $local_installer" | sha256sum -c 2> /dev/null > /dev/null)
then
    echo "Verified local installer was found: '$local_installer'"
else
    local_installer="$(mktemp -q -u)"

    echo "Downloading ESET Management Agent installer..."

    if test -n "$eraa_http_proxy_value"
    then
      export use_proxy=yes
      export http_proxy="$eraa_http_proxy_value"
      (wget --connect-timeout 300 --no-check-certificate -O "$local_installer" "$eraa_installer_url" || wget --connect-timeout 300 --no-proxy --no-check-certificate -O "$local_installer" "$eraa_installer_url" || curl --fail --connect-timeout 300 -k "$eraa_installer_url" > "$local_installer") && echo "$local_installer" >> "$cleanup_file"
    else
      (wget --connect-timeout 300 --no-check-certificate -O "$local_installer" "$eraa_installer_url" || curl --fail --connect-timeout 300 -k "$eraa_installer_url" > "$local_installer") && echo "$local_installer" >> "$cleanup_file"
    fi

    if test ! -s "$local_installer"
    then
       echo "Failed to download installer file"
       exit 2
    fi

    echo -n "Checking integrity of installer script " && echo "$eraa_installer_checksum  $local_installer" | sha256sum -c
fi

chmod +x "$local_installer"

command -v sudo > /dev/null && usesudo="sudo -E" || usesudo=""

export _ERAAGENT_PEER_CERT_PASSWORD="$eraa_peer_cert_pwd"

echo
echo Running installer script $local_installer
echo

$usesudo /bin/sh "$local_installer"\
   --skip-license \
   --hostname "$eraa_server_hostname"\
   --port "$eraa_server_port"\
   --cert-path "$local_cert_path"\
   --cert-password "env:_ERAAGENT_PEER_CERT_PASSWORD"\
   --cert-password-is-base64\
   --initial-static-group "$eraa_initial_sg_token"\
   --proxy-hostname 'ESET01' --proxy-port 3128 \
   --disable-imp-program\
   $(test -n "$local_ca_path" && echo --cert-auth-path "$local_ca_path")\
   $(test -n "$eraa_product_uuid" && echo --product-guid "$eraa_product_uuid")\
   $(test -n "$eraa_policy_data" && echo --custom-policy "$eraa_policy_data")
